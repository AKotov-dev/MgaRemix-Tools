#!/bin/bash

clear

#Алгоритм сжатия (xz, zstd)
algo="zstd"
#Назание финального модуля
module="distrib.sqfs"

#Проверка привилегий root
if [ "$EUID" -ne "0" ]; then read -p "Требуются привилегии root! Enter - Выход..."; exit; fi

#Проверка наличия qemu-img и mksquashfs
if [ ! -f /usr/bin/qemu-nbd -o ! -f /usr/bin/mksquashfs ]; then
 read -p "Требуются пакеты: qemu-img и squashfs-tools! Enter - Установить"
 urpmi --auto qemu-img squashfs-tools; echo
fi

#Проверка наличия *.vdi или *.qcow2
if [[ -z $(ls | grep -iE '.vdi|.qcow2') ]]; then
 read -p "Не найден файл ./*.vdi или ./*.qcow2 для конвертации! Enter - Выход..."
 exit
fi

#Сбрасываем атрибуты и определяем стиль шрифта
tput sgr0; color='\e[1m'; ncolor='\e[0m'

#Путь и файл .vdi или .qcow2 (последний в столбце)
DIR="$(pwd)"; VDI=$(ls -1 | grep -iE '.vdi|.qcow2' | tail -n1)

echo -e "${color}Конвертировать:${ncolor}"
echo "$VDI -> $module"
echo "---"
echo -e "${color}Продолжить - Enter, Ctrl+C - Выход...${ncolor}"; read a

#Удаляем созданный ранее модуль
rm -f ./$module

echo -e "${color}Размонтирование предыдущей сессии...${ncolor}"
if [ $(pidof mksquashfs) ]; then killall mksquashfs; fi; umount -l /mnt/vbox; qemu-nbd -d /dev/nbd0; echo

echo -e "${color}Подключаю модуль ядра 'nbd'${ncolor}"
if [[ -n $(lsmod | grep nbd) ]]; then rmmod nbd; fi && modprobe -v nbd max_part=63; echo

echo -e "${color}Монтирую ./$VDI в /dev/nbd0${ncolor}"
qemu-nbd -c /dev/nbd0 ./"$VDI"
while [[ -z $(fdisk -l | grep 'nbd0p') ]]; do echo "Ожидаю подключения /dev/nbd0..."; sleep 1; done; echo

#Ждём udev (завершение монтирования)
udevadm settle

echo -e "${color}Ищу раздел Linux на устройстве /dev/nbd0 для разметок MBR/EFI и монтирую в /mnt/vbox${ncolor}"
SYSPART=$(fdisk -l /dev/nbd0 | grep "83 Linux" | cut -d " " -f1 | tail -n1)
if [ -z "$SYSPART" ]; then
SYSPART=$(lsblk -r -p -o NAME,PARTTYPE /dev/nbd0 | grep '0fc63daf' | cut -d " " -f1)
fi

if [[ -z $SYSPART ]]; then
  echo; read -p "Не найден раздел Linux внутри VDI. Enter - Выход..."
  exit;
fi

echo "Выбран: $SYSPART"

#Создаю папку /mnt/vbox, если нет
[ ! -d /mnt/vbox ] && mkdir /mnt/vbox
#mount $(fdisk -l /dev/nbd0 | grep "83 Linux" | cut -d " " -f1 | tail -n1) /mnt/vbox
mount $SYSPART /mnt/vbox

#Если раздел не корневой - выходим...
if [ ! -d /mnt/vbox/etc ]; then
  echo; read -p "Разметка VDI должна быть простейшей: / + swap! Enter - Выход..."
  exit
fi
echo

echo "очищаю /mnt/vbox/etc/fstab"
echo "#VDI-to-SQFS Converter clean fstab..." > /mnt/vbox/etc/fstab
echo "none / overlay defaults 0 0" >> /mnt/vbox/etc/fstab

echo "удаляю /mnt/vbox/etc/X11/xorg.conf и /mnt/vbox/etc/harddrake2/*[^service.conf]"
rm -f /mnt/vbox/etc/X11/xorg.conf /mnt/vbox/etc/sysconfig/harddrake2/*[^service.conf]
echo "удаляю настройки виртуальной сети /mnt/vbox/etc/sysconfig/network-scripts/{ifcfg-enp*,ifcfg-eno*}"
rm -f /mnt/vbox/etc/sysconfig/network-scripts/{ifcfg-enp*,ifcfg-eno*}
echo "удаляю /mnt/vbox/lost+found и /mnt/vbox/dead.letter"
rm -rf /mnt/vbox/lost+found; rm -f /mnt/vbox/dead.letter
echo;

echo -e "${color}Создаю модуль MgaRemix ./$module${ncolor}"
cd /mnt/vbox

#Сжатие (сохраняем xattrs обязательно - по умолчанию)
mksquashfs ./ $DIR/$module -comp $algo -no-duplicates -noappend

#Выходим из каталога /mnt/vbox в текущий для демонтирования
cd $DIR; echo

echo -e "${color}Последовательное размонтирование, ждите...${ncolor}"
umount -lv /mnt/vbox
for i in $(fdisk -l | grep 'nbd0p' | awk '{ print $1 }'); do qemu-nbd -d $i; sleep 1; done

qemu-nbd -d /dev/nbd0

#Отключение модуля ядра
while [[ $(lsmod | grep nbd) ]]; do modprobe -rv nbd; sleep 1; done

#Выставляю права (под su - это $USER) и показываю размер
[ -f $DIR/$module ] && chown $USER:$USER $DIR/$module

echo; echo "---"; echo -e "${color}Завершено. Enter - Выход...${ncolor}"
read a

exit 0;
