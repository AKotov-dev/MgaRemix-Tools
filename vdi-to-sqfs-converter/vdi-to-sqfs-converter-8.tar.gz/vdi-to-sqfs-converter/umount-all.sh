#!/bin/bash

clear

#Выходим из каталога /mnt/vbox в текущий для демонтирования
cd $(pwd);
echo "Размонтирование..."; echo "---";
#umount -l /mnt/vbox; qemu-nbd -d /dev/nbd0; modprobe -r nbd && \

umount -lv /mnt/vbox
for i in $(fdisk -l | grep 'nbd0p' | awk '{ print $1 }')
do
qemu-nbd -d $i
done

qemu-nbd -d /dev/nbd0

if [[ $(lsmod | grep nbd) ]]; then rmmod nbd; fi;

echo; echo "---";
read -p "${color}Завершено. Enter - Выход..." a

exit 0
