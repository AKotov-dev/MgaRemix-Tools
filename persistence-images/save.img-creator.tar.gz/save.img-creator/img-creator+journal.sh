#!/bin/sh

clear
echo "Создаём save.img с журналированием..."
echo "Введите размер образа в гигабайтах от 1, 2, 3 или 4:"
read a

if [ -z $(echo $a | egrep -x "1|2|3|4") ]; then
echo "Значение не определено!"
exit 0
fi

case $a in
    1)
    b=1024
    ;;
    2)
    b=2048
    ;;
    3)
    b=3072
    ;;
    4)
    b=4090
    ;;
esac

clear
echo "Создаю образ ./save.img $aГб ($bМб), ждите..."
if [ -f ./save.img ]; then rm -f ./save.img ./save-${a}.zip; fi;
dd if=/dev/zero of=./save.img bs=1M count=$b status=progress
echo; echo "Форматирую ./save.img в EXT4 с меткой SAVE, ждите..."
mkfs -t ext4 -L SAVE ./save.img
e2fsck -f ./save.img

echo "Образ создан и отформатирован..."
blkid ./save.img
echo; echo "Сжимаю ./save.img в ./save-${a}gb.zip..."
zip ./save-"$a"gb.zip ./save.img
echo "Завершено..."